const mongoose = require('mongoose');

const egresoSchema = new mongoose.Schema({
  descripcion: { type: String, required: true },
  monto: { type: Number, required: true },
  categoria: { type: String, required: true },
  metodoPago: { type: String, required: true },
  fecha: { type: Date, required: true },
  observaciones: { type: String },
  usuario: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }
});

module.exports = mongoose.model('Egreso', egresoSchema);

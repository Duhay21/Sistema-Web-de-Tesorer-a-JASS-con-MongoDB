const Ingreso = require('../models/Ingreso');
const Egreso = require('../models/Egreso');

exports.getDashboard = async (req, res) => {
  try {
    const ingresos = await Ingreso.aggregate([
      { $match: { usuario: req.user.id } },
      { $group: { _id: null, total: { $sum: '$monto' } } }
    ]);

    const egresos = await Egreso.aggregate([
      { $match: { usuario: req.user.id } },
      { $group: { _id: null, total: { $sum: '$monto' } } }
    ]);

    const totalIngresos = ingresos[0]?.total || 0;
    const totalEgresos = egresos[0]?.total || 0;
    const saldo = totalIngresos - totalEgresos;

    res.json({ totalIngresos, totalEgresos, saldo });
  } catch (error) {
    console.error(error);
    res.status(500).send('Error al obtener datos del dashboard');
  }
};

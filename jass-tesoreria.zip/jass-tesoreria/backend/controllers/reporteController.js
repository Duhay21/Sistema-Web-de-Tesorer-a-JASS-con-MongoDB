const Ingreso = require('../models/Ingreso');
const Egreso = require('../models/Egreso');
const generarPDF = require('../utils/pdfGenerator');
const generarCSV = require('../utils/excelGenerator');

exports.getReportePDF = async (req, res) => {
  try {
    const { tipo } = req.query; // tipo=ingreso o tipo=egreso
    if (!['ingreso', 'egreso'].includes(tipo)) {
      return res.status(400).json({ msg: 'Tipo inválido' });
    }

    const Model = tipo === 'ingreso' ? Ingreso : Egreso;
    const data = await Model.find({ usuario: req.user.id }).sort({ fecha: -1 });

    const pdfBuffer = await generarPDF(data, tipo === 'ingreso' ? 'Ingresos' : 'Egresos');

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=${tipo}s-reporte.pdf`);
    res.send(pdfBuffer);
  } catch (error) {
    console.error(error);
    res.status(500).send('Error al generar PDF');
  }
};

exports.getReporteCSV = async (req, res) => {
  try {
    const { tipo } = req.query; // tipo=ingreso o tipo=egreso
    if (!['ingreso', 'egreso'].includes(tipo)) {
      return res.status(400).json({ msg: 'Tipo inválido' });
    }

    const Model = tipo === 'ingreso' ? Ingreso : Egreso;
    const data = await Model.find({ usuario: req.user.id }).sort({ fecha: -1 });

    const csv = generarCSV(data);

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename=${tipo}s-reporte.csv`);
    res.send(csv);
  } catch (error) {
    console.error(error);
    res.status(500).send('Error al generar CSV');
  }
};

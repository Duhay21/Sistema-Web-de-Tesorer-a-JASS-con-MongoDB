const Egreso = require('../models/Egreso');

exports.getEgresos = async (req, res) => {
  try {
    const egresos = await Egreso.find({ usuario: req.user.id });
    res.json(egresos);
  } catch (error) {
    res.status(500).send('Error al obtener egresos');
  }
};

exports.createEgreso = async (req, res) => {
  try {
    const egreso = new Egreso({ ...req.body, usuario: req.user.id });
    await egreso.save();
    res.json(egreso);
  } catch (error) {
    res.status(500).send('Error al crear egreso');
  }
};

exports.updateEgreso = async (req, res) => {
  try {
    const egreso = await Egreso.findOneAndUpdate(
      { _id: req.params.id, usuario: req.user.id },
      req.body,
      { new: true }
    );
    if (!egreso) return res.status(404).json({ msg: 'Egreso no encontrado' });
    res.json(egreso);
  } catch (error) {
    res.status(500).send('Error al actualizar egreso');
  }
};

exports.deleteEgreso = async (req, res) => {
  try {
    const egreso = await Egreso.findOneAndDelete({ _id: req.params.id, usuario: req.user.id });
    if (!egreso) return res.status(404).json({ msg: 'Egreso no encontrado' });
    res.json({ msg: 'Egreso eliminado' });
  } catch (error) {
    res.status(500).send('Error al eliminar egreso');
  }
};

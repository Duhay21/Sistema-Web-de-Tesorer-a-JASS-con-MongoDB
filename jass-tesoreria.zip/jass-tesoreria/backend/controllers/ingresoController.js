const Ingreso = require('../models/Ingreso');

exports.getIngresos = async (req, res) => {
  try {
    const ingresos = await Ingreso.find({ usuario: req.user.id });
    res.json(ingresos);
  } catch (error) {
    res.status(500).send('Error al obtener ingresos');
  }
};

exports.createIngreso = async (req, res) => {
  try {
    const ingreso = new Ingreso({ ...req.body, usuario: req.user.id });
    await ingreso.save();
    res.json(ingreso);
  } catch (error) {
    res.status(500).send('Error al crear ingreso');
  }
};

exports.updateIngreso = async (req, res) => {
  try {
    const ingreso = await Ingreso.findOneAndUpdate(
      { _id: req.params.id, usuario: req.user.id },
      req.body,
      { new: true }
    );
    if (!ingreso) return res.status(404).json({ msg: 'Ingreso no encontrado' });
    res.json(ingreso);
  } catch (error) {
    res.status(500).send('Error al actualizar ingreso');
  }
};

exports.deleteIngreso = async (req, res) => {
  try {
    const ingreso = await Ingreso.findOneAndDelete({ _id: req.params.id, usuario: req.user.id });
    if (!ingreso) return res.status(404).json({ msg: 'Ingreso no encontrado' });
    res.json({ msg: 'Ingreso eliminado' });
  } catch (error) {
    res.status(500).send('Error al eliminar ingreso');
  }
};

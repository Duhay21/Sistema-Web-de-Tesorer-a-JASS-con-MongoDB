const express = require('express');
const router = express.Router();
const reporteController = require('../controllers/reporteController');
const authMiddleware = require('../middleware/authMiddleware');

router.get('/pdf', authMiddleware, reporteController.getReportePDF);
router.get('/csv', authMiddleware, reporteController.getReporteCSV);

module.exports = router;

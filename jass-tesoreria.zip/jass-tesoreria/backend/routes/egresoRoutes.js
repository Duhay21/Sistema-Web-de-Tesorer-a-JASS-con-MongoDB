const express = require('express');
const router = express.Router();
const egresoController = require('../controllers/egresoController');
const authMiddleware = require('../middleware/authMiddleware');

router.get('/', authMiddleware, egresoController.getEgresos);
router.post('/', authMiddleware, egresoController.createEgreso);
router.put('/:id', authMiddleware, egresoController.updateEgreso);
router.delete('/:id', authMiddleware, egresoController.deleteEgreso);

module.exports = router;

const express = require('express');
const router = express.Router();
const ingresoController = require('../controllers/ingresoController');
const authMiddleware = require('../middleware/authMiddleware');

router.get('/', authMiddleware, ingresoController.getIngresos);
router.post('/', authMiddleware, ingresoController.createIngreso);
router.put('/:id', authMiddleware, ingresoController.updateIngreso);
router.delete('/:id', authMiddleware, ingresoController.deleteIngreso);

module.exports = router;

function generarCSV(data) {
  const headers = ['Descripción', 'Monto', 'Categoría', 'Método de Pago', 'Fecha', 'Observaciones'];
  const rows = data.map(item => [
    `"${item.descripcion.replace(/"/g, '""')}"`,
    item.monto,
    `"${item.categoria.replace(/"/g, '""')}"`,
    `"${item.metodoPago.replace(/"/g, '""')}"`,
    new Date(item.fecha).toISOString().split('T')[0],
    `"${(item.observaciones || '').replace(/"/g, '""')}"`
  ]);

  const csvContent = [
    headers.join(','),
    ...rows.map(r => r.join(','))
  ].join('\n');

  return csvContent;
}

module.exports = generarCSV;

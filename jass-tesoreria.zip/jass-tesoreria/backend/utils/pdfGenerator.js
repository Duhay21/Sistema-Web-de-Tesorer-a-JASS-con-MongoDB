const PDFDocument = require('pdfkit');

function generarPDF(data, tipo = 'Ingresos') {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ margin: 30, size: 'A4' });
      const buffers = [];

      doc.on('data', buffers.push.bind(buffers));
      doc.on('end', () => {
        const pdfData = Buffer.concat(buffers);
        resolve(pdfData);
      });

      doc.fontSize(20).text(`${tipo} Reporte`, { align: 'center' });
      doc.moveDown();

      doc.fontSize(12);
      data.forEach((item, i) => {
        doc.text(
          `${i + 1}. ${item.descripcion} | Monto: $${item.monto.toFixed(2)} | Categoría: ${item.categoria} | Método: ${item.metodoPago} | Fecha: ${new Date(item.fecha).toLocaleDateString()} | Obs: ${item.observaciones || ''}`
        );
        doc.moveDown(0.5);
      });

      doc.end();
    } catch (error) {
      reject(error);
    }
  });
}

module.exports = generarPDF;

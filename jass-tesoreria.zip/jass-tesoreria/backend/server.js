require('dotenv').config();
const express = require('express');
const conectarDB = require('./config/db');
const cors = require('cors');

const app = express();

conectarDB();

app.use(cors());
app.use(express.json());

app.use('/api/users', require('./routes/userRoutes'));
app.use('/api/ingresos', require('./routes/ingresoRoutes'));
app.use('/api/egresos', require('./routes/egresoRoutes'));
// ...
app.use('/api/dashboard', require('./routes/dashboardRoutes'));
app.use('/api/reportes', require('./routes/reporteRoutes'));
// ...

// Rutas para reportes y utilitarios se pueden agregar luego

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Servidor corriendo en puerto ${PORT}`));

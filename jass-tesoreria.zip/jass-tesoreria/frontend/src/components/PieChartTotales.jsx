import React from 'react';
import { PieChart, Pie, Cell, Legend, Tooltip } from 'recharts';
import '../styles/PieChartTotales.css'; // 👈 Agrega esta línea

const COLORS = ['#0088FE', '#FF8042'];

export default function PieChartTotales({ totalIngresos, totalEgresos }) {
  const data = [
    { name: 'Ingresos', value: totalIngresos },
    { name: 'Egresos', value: totalEgresos }
  ];

  return (
    <div className="chart-container">
      <h3 className="chart-title">Distribución de Totales</h3>
      <PieChart width={300} height={250}>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          labelLine={false}
          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
          outerRadius={80}
          fill="#8884d8"
          dataKey="value"
        >
          {data.map((entry, index) => (
            <Cell key={index} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip formatter={value => `$${value}`} />
        <Legend verticalAlign="bottom" height={36} />
      </PieChart>
    </div>
  );
}

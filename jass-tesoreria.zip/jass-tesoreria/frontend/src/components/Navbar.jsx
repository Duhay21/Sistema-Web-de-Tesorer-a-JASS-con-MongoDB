import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function Navbar() {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  const logout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <nav className="navbar">
      <div className="navbar-logo">JASS Tesorería</div>
      <ul className="navbar-links">
        {token ? (
          <>
            <li><Link to="/dashboard">Dashboard</Link></li>
            <li><Link to="/ingresos">Ingresos</Link></li>
            <li><Link to="/egresos">Egresos</Link></li>
            <li><Link to="/reportes">Reportes</Link></li>
            <li><button className="btn-logout" onClick={logout}>Cerrar sesión</button></li>
          </>
        ) : (
          <>
            <li><Link to="/login">Iniciar sesión</Link></li>
            <li><Link to="/register">Registrarse</Link></li>
          </>
        )}
      </ul>
    </nav>
  );
}

import React, { useEffect, useState } from 'react';
import api from '../api';
import '../styles/Ingresos.css';

export default function Ingresos() {
  const [ingresos, setIngresos] = useState([]);
  const [formData, setFormData] = useState({
    descripcion: '',
    monto: '',
    categoria: '',
    metodoPago: '',
    fecha: '',
    observaciones: ''
  });
  const [editingId, setEditingId] = useState(null);
  const [error, setError] = useState('');

  const categorias = ['Ventas', 'Servicios', 'Otros'];
  const metodosPago = ['Efectivo', 'Tarjeta', 'Transferencia', 'Otro'];

  const fetchIngresos = async () => {
    try {
      const res = await api.get('/ingresos');
      setIngresos(res.data);
    } catch (err) {
      setError('Error al cargar ingresos');
    }
  };

  useEffect(() => {
    fetchIngresos();
  }, []);

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const resetForm = () => {
    setFormData({
      descripcion: '',
      monto: '',
      categoria: '',
      metodoPago: '',
      fecha: '',
      observaciones: ''
    });
    setEditingId(null);
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const { descripcion, monto, categoria, metodoPago, fecha } = formData;
    if (!descripcion || !monto || !categoria || !metodoPago || !fecha) {
      setError('Por favor completa todos los campos obligatorios');
      return;
    }
    try {
      if (editingId) {
        await api.put(`/ingresos/${editingId}`, formData);
      } else {
        await api.post('/ingresos', formData);
      }
      resetForm();
      fetchIngresos();
      setError('');
    } catch (err) {
      setError('Error al guardar ingreso');
    }
  };

  const handleEdit = ingreso => {
    setFormData({
      descripcion: ingreso.descripcion,
      monto: ingreso.monto,
      categoria: ingreso.categoria,
      metodoPago: ingreso.metodoPago,
      fecha: ingreso.fecha.split('T')[0],
      observaciones: ingreso.observaciones || ''
    });
    setEditingId(ingreso._id);
  };

  const handleDelete = async id => {
    if (window.confirm('¿Seguro que quieres eliminar este ingreso?')) {
      try {
        await api.delete(`/ingresos/${id}`);
        fetchIngresos();
      } catch {
        setError('Error al eliminar ingreso');
      }
    }
  };

  return (
    <div className="ingresos-container">
      <h2>Ingresos</h2>
      {error && <p className="error-msg">{error}</p>}

      <form onSubmit={handleSubmit} className="form-ingreso">
        <input
          type="text"
          name="descripcion"
          placeholder="Descripción"
          value={formData.descripcion}
          onChange={handleChange}
          required
        />
        <input
          type="number"
          name="monto"
          placeholder="Monto"
          value={formData.monto}
          onChange={handleChange}
          required
          min="0"
          step="0.01"
        />
        <select name="categoria" value={formData.categoria} onChange={handleChange} required>
          <option value="">Seleccione categoría</option>
          {categorias.map(cat => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
        <select name="metodoPago" value={formData.metodoPago} onChange={handleChange} required>
          <option value="">Seleccione método de pago</option>
          {metodosPago.map(met => (
            <option key={met} value={met}>{met}</option>
          ))}
        </select>
        <input
          type="date"
          name="fecha"
          value={formData.fecha}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="observaciones"
          placeholder="Observaciones (opcional)"
          value={formData.observaciones}
          onChange={handleChange}
        />
        <button type="submit">{editingId ? 'Actualizar' : 'Agregar'}</button>
        {editingId && <button type="button" onClick={resetForm} className="btn-cancel">Cancelar</button>}
      </form>

      <table className="tabla-ingresos">
        <thead>
          <tr>
            <th>Descripción</th>
            <th>Monto</th>
            <th>Categoría</th>
            <th>Método Pago</th>
            <th>Fecha</th>
            <th>Observaciones</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {ingresos.map(ing => (
            <tr key={ing._id}>
              <td>{ing.descripcion}</td>
              <td>${ing.monto.toFixed(2)}</td>
              <td>{ing.categoria}</td>
              <td>{ing.metodoPago}</td>
              <td>{new Date(ing.fecha).toLocaleDateString()}</td>
              <td>{ing.observaciones}</td>
              <td>
                <button onClick={() => handleEdit(ing)}>Editar</button>
                <button onClick={() => handleDelete(ing._id)} className="btn-eliminar">Eliminar</button>
              </td>
            </tr>
          ))}
          {ingresos.length === 0 && (
            <tr><td colSpan="7" style={{ textAlign: 'center' }}>No hay ingresos registrados.</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

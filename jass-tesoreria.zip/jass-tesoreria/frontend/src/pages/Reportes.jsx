import React, { useState } from 'react';
import '../styles/Reportes.css';

export default function Reportes() {
  const [tipo, setTipo] = useState('ingreso');
  const [formato, setFormato] = useState('pdf');
  const [mensaje, setMensaje] = useState('');

  const descargarReporte = () => {
    const url = `http://localhost:5000/api/reportes/${formato}?tipo=${tipo}`;
    setMensaje('');
    fetch(url, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    }).then(res => {
      if (!res.ok) {
        setMensaje('Error al descargar reporte');
        return;
      }
      return res.blob();
    }).then(blob => {
      if (!blob) return;
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = `${tipo}s-reporte.${formato}`;
      link.click();
    }).catch(() => setMensaje('Error al descargar reporte'));
  };

  return (
    <div className="reportes-container">
      <h2>Descargar Reportes</h2>
      <div className="form-reportes">
        <label>
          Tipo:
          <select value={tipo} onChange={e => setTipo(e.target.value)}>
            <option value="ingreso">Ingresos</option>
            <option value="egreso">Egresos</option>
          </select>
        </label>
        <label>
          Formato:
          <select value={formato} onChange={e => setFormato(e.target.value)}>
            <option value="pdf">PDF</option>
            <option value="csv">CSV</option>
          </select>
        </label>
        <button onClick={descargarReporte}>Descargar</button>
      </div>
      {mensaje && <p className="error-msg">{mensaje}</p>}
    </div>
  );
}

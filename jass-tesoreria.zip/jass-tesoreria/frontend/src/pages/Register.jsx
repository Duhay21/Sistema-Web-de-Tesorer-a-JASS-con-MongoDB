import React, { useState } from 'react';
import api from '../api';
import { useNavigate } from 'react-router-dom';
import '../styles/Register.css';

export default function Register() {
  const [nombre, setNombre] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      await api.post('/users/register', { nombre, email, password });
      navigate('/login');
    } catch (err) {
      setError(err.response?.data?.msg || 'Error al registrar usuario');
    }
  };

  return (
    <div className="register-container">
      <h2>Registrarse</h2>
      <form onSubmit={handleSubmit} className="form-register">
        <input type="text" placeholder="Nombre completo" required
          value={nombre} onChange={e => setNombre(e.target.value)} />
        <input type="email" placeholder="Correo electrónico" required
          value={email} onChange={e => setEmail(e.target.value)} />
        <input type="password" placeholder="Contraseña" required
          value={password} onChange={e => setPassword(e.target.value)} />
        <button type="submit">Registrar</button>
      </form>
      {error && <p className="error-msg">{error}</p>}
      <p>¿Ya tienes cuenta? <a href="/login">Inicia sesión</a></p>
    </div>
  );
}

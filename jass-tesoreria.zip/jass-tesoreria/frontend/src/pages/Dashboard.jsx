import React, { useEffect, useState } from "react";
import api from "../api";
import { PieChart, Pie, Cell, Legend, Tooltip, ResponsiveContainer } from "recharts";

const COLORS = ["#1a73e8", "#e63946"]; // Azul para ingreso, rojo para egreso

export default function Dashboard() {
  const [totales, setTotales] = useState({ ingresos: 0, egresos: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function fetchTotales() {
      try {
        const ingresosRes = await api.get("/ingresos");
        const egresosRes = await api.get("/egresos");

        const ingresosSum = ingresosRes.data.reduce((a, b) => a + b.monto, 0);
        const egresosSum = egresosRes.data.reduce((a, b) => a + b.monto, 0);

        setTotales({ ingresos: ingresosSum, egresos: egresosSum });
        setLoading(false);
      } catch (err) {
        setError("Error al cargar datos");
        setLoading(false);
      }
    }
    fetchTotales();
  }, []);

  const saldoActual = totales.ingresos - totales.egresos;

  const data = [
    { name: "Ingresos", value: totales.ingresos },
    { name: "Egresos", value: totales.egresos },
  ];

  return (
    <div className="dashboard-container">
      <h2>Dashboard Financiero</h2>

      {error && <p className="error-msg">{error}</p>}
      {loading ? (
        <p>Cargando datos...</p>
      ) : (
        <>
          <p className="saldo">
            Saldo actual:{" "}
            <span style={{ color: saldoActual >= 0 ? "#1a7e3e" : "#d42f2f", fontWeight: "800" }}>
              ${saldoActual.toFixed(2)}
            </span>
          </p>

          <ResponsiveContainer width="100%" height={350}>
            <PieChart>
              <Pie
                dataKey="value"
                data={data}
                cx="50%"
                cy="50%"
                outerRadius={110}
                fill="#8884d8"
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Legend verticalAlign="bottom" height={36} />
              <Tooltip formatter={(value) => `$${value.toFixed(2)}`} />
            </PieChart>
          </ResponsiveContainer>
        </>
      )}
    </div>
  );
}

import React, { useEffect, useState } from 'react';
import api from '../api';
import '../styles/Egresos.css';

export default function Egresos() {
  const [egresos, setEgresos] = useState([]);
  const [formData, setFormData] = useState({
    descripcion: '',
    monto: '',
    categoria: '',
    metodoPago: '',
    fecha: '',
    observaciones: ''
  });
  const [editingId, setEditingId] = useState(null);
  const [error, setError] = useState('');

  const categorias = ['Compras', 'Servicios', 'Otros'];
  const metodosPago = ['Efectivo', 'Tarjeta', 'Transferencia', 'Otro'];

  const fetchEgresos = async () => {
    try {
      const res = await api.get('/egresos');
      setEgresos(res.data);
    } catch (err) {
      setError('Error al cargar egresos');
    }
  };

  useEffect(() => {
    fetchEgresos();
  }, []);

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const resetForm = () => {
    setFormData({
      descripcion: '',
      monto: '',
      categoria: '',
      metodoPago: '',
      fecha: '',
      observaciones: ''
    });
    setEditingId(null);
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const { descripcion, monto, categoria, metodoPago, fecha } = formData;
    if (!descripcion || !monto || !categoria || !metodoPago || !fecha) {
      setError('Por favor completa todos los campos obligatorios');
      return;
    }
    try {
      if (editingId) {
        await api.put(`/egresos/${editingId}`, formData);
      } else {
        await api.post('/egresos', formData);
      }
      resetForm();
      fetchEgresos();
      setError('');
    } catch (err) {
      setError('Error al guardar egreso');
    }
  };

  const handleEdit = egreso => {
    setFormData({
      descripcion: egreso.descripcion,
      monto: egreso.monto,
      categoria: egreso.categoria,
      metodoPago: egreso.metodoPago,
      fecha: egreso.fecha.split('T')[0],
      observaciones: egreso.observaciones || ''
    });
    setEditingId(egreso._id);
  };

  const handleDelete = async id => {
    if (window.confirm('¿Seguro que quieres eliminar este egreso?')) {
      try {
        await api.delete(`/egresos/${id}`);
        fetchEgresos();
      } catch {
        setError('Error al eliminar egreso');
      }
    }
  };

  return (
    <div className="egresos-container">
      <h2>Egresos</h2>
      {error && <p className="error-msg">{error}</p>}

      <form onSubmit={handleSubmit} className="form-egreso">
        <input
          type="text"
          name="descripcion"
          placeholder="Descripción"
          value={formData.descripcion}
          onChange={handleChange}
          required
        />
        <input
          type="number"
          name="monto"
          placeholder="Monto"
          value={formData.monto}
          onChange={handleChange}
          required
          min="0"
          step="0.01"
        />
        <select name="categoria" value={formData.categoria} onChange={handleChange} required>
          <option value="">Seleccione categoría</option>
          {categorias.map(cat => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
        <select name="metodoPago" value={formData.metodoPago} onChange={handleChange} required>
          <option value="">Seleccione método de pago</option>
          {metodosPago.map(met => (
            <option key={met} value={met}>{met}</option>
          ))}
        </select>
        <input
          type="date"
          name="fecha"
          value={formData.fecha}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="observaciones"
          placeholder="Observaciones (opcional)"
          value={formData.observaciones}
          onChange={handleChange}
        />
        <button type="submit">{editingId ? 'Actualizar' : 'Agregar'}</button>
        {editingId && <button type="button" onClick={resetForm} className="btn-cancel">Cancelar</button>}
      </form>

      <table className="tabla-egresos">
        <thead>
          <tr>
            <th>Descripción</th>
            <th>Monto</th>
            <th>Categoría</th>
            <th>Método Pago</th>
            <th>Fecha</th>
            <th>Observaciones</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {egresos.map(eg => (
            <tr key={eg._id}>
              <td>{eg.descripcion}</td>
              <td>${eg.monto.toFixed(2)}</td>
              <td>{eg.categoria}</td>
              <td>{eg.metodoPago}</td>
              <td>{new Date(eg.fecha).toLocaleDateString()}</td>
              <td>{eg.observaciones}</td>
              <td>
                <button onClick={() => handleEdit(eg)}>Editar</button>
                <button onClick={() => handleDelete(eg._id)} className="btn-eliminar">Eliminar</button>
              </td>
            </tr>
          ))}
          {egresos.length === 0 && (
            <tr><td colSpan="7" style={{ textAlign: 'center' }}>No hay egresos registrados.</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

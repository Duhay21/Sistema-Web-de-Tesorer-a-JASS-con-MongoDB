import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./styles/Navbar.css";
import "./styles/Login.css";
import "./styles/Register.css";
import "./styles/Dashboard.css";
import "./styles/Ingresos.css";
import "./styles/Egresos.css";
import "./styles/Reportes.css";
import "./styles/PieChartTotales.css";

const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
